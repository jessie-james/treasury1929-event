import express, { type Express } from "express";
import { createServer } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertBookingSchema, insertAdminLogSchema, bookings, events, adminLogs, InsertUser, User } from "@shared/schema";
import { z } from "zod";
import { setupAuth, hashPassword } from "./auth";
import Stripe from "stripe";
import multer from "multer";
import path from "path";
import fs from "fs";
import { randomUUID } from "crypto";
import { eq } from "drizzle-orm";
import { db } from "./db";

// Initialize Stripe with the secret key
if (!process.env.STRIPE_SECRET_KEY) {
  console.error("STRIPE_SECRET_KEY environment variable not set. Stripe payments will not work.");
}

// Explicitly define API version for type safety
const stripeApiVersion = "2023-10-16" as Stripe.LatestApiVersion;

// Initialize Stripe with better error handling
let stripe: Stripe | null = null;
let stripeInitAttempt = 0;
const MAX_INIT_ATTEMPTS = 3;

// Function to initialize Stripe with retry logic
function initializeStripe() {
  stripeInitAttempt++;
  try {
    if (process.env.STRIPE_SECRET_KEY) {
      console.log(`Initializing Stripe (attempt ${stripeInitAttempt})...`);
      
      // Additional logging for deployment debugging
      const keyPrefix = process.env.STRIPE_SECRET_KEY.substring(0, 7);
      console.log(`Using Stripe key with prefix: ${keyPrefix}...`);
      
      // Create Stripe instance with more resilient settings for deployment
      stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
        apiVersion: stripeApiVersion,
        timeout: 20000, // 20 second timeout for API requests in deployment
        maxNetworkRetries: 3, // Retry network requests up to 3 times
        httpAgent: undefined, // Let Stripe handle the HTTP agent
      });
      
      console.log("✓ Stripe initialized successfully");
      return true;
    } else {
      console.error("× Cannot initialize Stripe: STRIPE_SECRET_KEY is missing");
      return false;
    }
  } catch (error) {
    console.error(`× Failed to initialize Stripe (attempt ${stripeInitAttempt}):`, error);
    return false;
  }
}

// Initial initialization attempt
(async () => {
  // Attempt initialization immediately
  const success = initializeStripe();
  
  // If initial attempt fails, try once more after a delay
  // This helps in deployment environments where secrets might load with a delay
  if (!success) {
    console.log("First Stripe initialization failed, retrying after delay...");
    setTimeout(() => {
      if (initializeStripe()) {
        console.log("Delayed Stripe initialization succeeded");
      } else {
        console.error("Delayed Stripe initialization also failed");
      }
    }, 3000); // 3 second delay
  }
})();

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configure multer storage for handling file uploads
const storage_config = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadsDir);
  },
  filename: function (req, file, cb) {
    // Generate unique filename with original extension
    const uniqueFilename = `${randomUUID()}${path.extname(file.originalname)}`;
    cb(null, uniqueFilename);
  }
});

// Only allow specific image file types
const fileFilter = (req: any, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  // Expanded list of common image MIME types
  const allowedMimeTypes = [
    'image/jpeg', 
    'image/jpg',  // Some browsers/systems might use this variant
    'image/pjpeg', // Progressive JPEG
    'image/png', 
    'image/gif', 
    'image/webp',
    'image/svg+xml', // SVG images
    'image/bmp'     // BMP images
  ];
  
  console.log(`Receiving file upload: ${file.originalname}, MIME type: ${file.mimetype}`);
  
  if (allowedMimeTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    const error = new Error(`Invalid file type: ${file.mimetype}. Only JPEG, PNG, GIF, WebP, SVG and BMP images are allowed.`);
    console.error(`File upload rejected: ${error.message}`);
    cb(error);
  }
};

const upload = multer({ 
  storage: storage_config,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB max file size
  },
  fileFilter
});

const clients = new Set<WebSocket>();

// Helper function to reset test data
async function clearAllBookings() {
  try {
    // Clear all bookings
    await db.delete(bookings);
    
    // Reset event available seats to total seats
    const allEvents = await db.select().from(events);
    for (const event of allEvents) {
      await db.update(events)
        .set({ availableSeats: event.totalSeats })
        .where(eq(events.id, event.id));
    }
    
    return { success: true, message: "All bookings cleared and event seats reset" };
  } catch (error) {
    console.error("Error clearing bookings:", error);
    return { success: false, message: "Failed to clear bookings" };
  }
}

// Validation schemas for reordering requests
const updateEventsOrderSchema = z.object({
  orderedIds: z.array(z.number())
});

const updateFoodOptionsOrderSchema = z.object({
  orderedIds: z.array(z.number())
});

export async function registerRoutes(app: Express) {
  // Set up authentication
  setupAuth(app);

  const httpServer = createServer(app);

  // Create WebSocket server after HTTP server but before routes
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: '/ws',
    perMessageDeflate: false // Disable compression for faster startup
  });

  // Keep track of connected clients and their events of interest
  const clientSubscriptions = new Map<WebSocket, Set<number>>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    clientSubscriptions.set(ws, new Set());
    
    // Handle messages from clients
    ws.on('message', (message) => {
      try {
        const data = JSON.parse(message.toString());
        if (data.type === 'subscribe_event' && typeof data.eventId === 'number') {
          // Subscribe client to updates for a specific event
          const subscriptions = clientSubscriptions.get(ws);
          if (subscriptions) {
            subscriptions.add(data.eventId);
            console.log(`Client subscribed to event ${data.eventId}`);
          }
        }
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    });
    
    ws.on('close', () => {
      clients.delete(ws);
      clientSubscriptions.delete(ws);
    });
  });

  // Test database connection
  app.get("/api/health", async (_req, res) => {
    try {
      await storage.getUser(1);
      res.json({ status: "healthy", database: "connected" });
    } catch (error) {
      console.error("Database health check failed:", error);
      res.status(500).json({ 
        status: "unhealthy", 
        database: "disconnected",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Broadcast updates to all connected clients
  const broadcastAvailability = async (eventId: number) => {
    try {
      const event = await storage.getEvent(eventId);
      if (!event) return;

      const message = JSON.stringify({
        type: 'availability_update',
        eventId: event.id,
        availableSeats: event.availableSeats
      });

      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });
    } catch (error) {
      console.error("Error broadcasting availability:", error);
    }
  };
  
  // Broadcast check-in updates to subscribed clients
  const broadcastCheckInUpdate = async (eventId: number) => {
    try {
      // Get updated check-in stats
      const checkInStats = await storage.getEventCheckInStats(eventId);
      
      const message = JSON.stringify({
        type: 'checkin_update',
        eventId,
        stats: checkInStats
      });
      
      // Send to clients who subscribed to this event
      clientSubscriptions.forEach((subscriptions, client) => {
        if (client.readyState === WebSocket.OPEN && subscriptions.has(eventId)) {
          client.send(message);
        }
      })
    } catch (error) {
      console.error(`Error broadcasting check-in update for event ${eventId}:`, error);
    }
  };

  // Add new CRUD endpoints for events
  app.post("/api/events", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Ensure date is properly formatted as a Date object
      let formattedDate;
      try {
        // Check if date is a string representation
        if (typeof req.body.date === 'string') {
          formattedDate = new Date(req.body.date);
          // Validate that the date was parsed correctly
          if (isNaN(formattedDate.getTime())) {
            throw new Error("Invalid date format");
          }
        } else {
          // If it's not a string, try to use it directly
          formattedDate = new Date(req.body.date);
        }
      } catch (dateError) {
        console.error("Date conversion error:", dateError);
        return res.status(400).json({
          message: "Invalid date format",
          error: String(dateError)
        });
      }

      console.log("Creating event with data:", {
        ...req.body,
        date: formattedDate.toISOString()
      });
      
      const event = await storage.createEvent({
        ...req.body,
        date: formattedDate,
        totalSeats: Number(req.body.totalSeats),
        venueId: 1, // For now, hardcode to venue 1
      });
      
      console.log("Event created successfully:", event);
      
      // Create detailed admin log
      await storage.createAdminLog({
        userId: req.user.id,
        action: "create_event",
        entityType: "event",
        entityId: event.id,
        details: {
          title: event.title,
          date: event.date,
          totalSeats: event.totalSeats,
          image: event.image
        }
      });
      
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating event:", error);
      res.status(500).json({ 
        message: "Failed to create event",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.patch("/api/events/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      
      // Handle date formatting if it's being updated
      let updateData = { ...req.body };
      
      if (req.body.date) {
        try {
          // Convert string date to Date object
          const formattedDate = new Date(req.body.date);
          
          // Validate date
          if (isNaN(formattedDate.getTime())) {
            throw new Error("Invalid date format");
          }
          
          // Update with proper Date object
          updateData.date = formattedDate;
          
        } catch (dateError) {
          console.error("Date conversion error during update:", dateError);
          return res.status(400).json({
            message: "Invalid date format",
            error: String(dateError)
          });
        }
      }

      console.log("Updating event with data:", updateData);
      
      // Get original event data for comparison
      const originalEvent = await storage.getEvent(id);
      if (!originalEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const event = await storage.updateEvent(id, updateData);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      console.log("Event updated successfully:", event);
      
      // Track specific changes for more detailed logging
      const changes: Record<string, { from: any, to: any }> = {};
      for (const key of Object.keys(updateData)) {
        if (JSON.stringify(originalEvent[key as keyof typeof originalEvent]) !== 
            JSON.stringify(event[key as keyof typeof event])) {
          changes[key] = {
            from: originalEvent[key as keyof typeof originalEvent],
            to: event[key as keyof typeof event]
          };
        }
      }
      
      // Create detailed admin log for event update
      await storage.createAdminLog({
        userId: req.user.id,
        action: "update_event",
        entityType: "event",
        entityId: id,
        details: {
          title: event.title,
          date: event.date,
          changes: changes,
          image: event.image
        }
      });
      
      res.json(event);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(500).json({ 
        message: "Failed to update event",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.delete("/api/events/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      
      // Get event details before deletion for logging
      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      await storage.deleteEvent(id);
      
      // Create detailed admin log for event deletion
      await storage.createAdminLog({
        userId: req.user.id,
        action: "delete_event",
        entityType: "event",
        entityId: id,
        details: {
          title: event.title,
          date: event.date
        }
      });
      
      res.sendStatus(200);
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Failed to delete event" });
    }
  });

  app.get("/api/events", async (_req, res) => {
    try {
      // Get events ordered by display_order by default
      const events = await storage.getEventsByDisplayOrder();
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const event = await storage.getEvent(id);
      if (!event) {
        res.status(404).json({ message: "Event not found" });
        return;
      }
      res.json(event);
    } catch (error) {
      console.error("Error fetching event:", error);
      res.status(500).json({ message: "Failed to fetch event" });
    }
  });

  app.get("/api/tables", async (_req, res) => {
    try {
      // Return a simplified temporary implementation
      console.log("Using temporary implementation for /api/tables");
      res.json([
        { id: 1, tableNumber: 1, capacity: 4 }
      ]);
    } catch (error) {
      console.error("Error fetching tables:", error);
      res.status(500).json({ message: "Failed to fetch tables" });
    }
  });

  app.get("/api/tables/:tableId/seats", async (req, res) => {
    try {
      const tableId = parseInt(req.params.tableId);
      const eventId = parseInt(req.query.eventId as string);

      if (!eventId) {
        return res.status(400).json({ message: "eventId query parameter is required" });
      }

      console.log(`Getting seat availability for table ${tableId}, event ${eventId}`);
      
      // Get all bookings for this event
      const allBookings = await storage.getBookings();
      const eventBookings = allBookings.filter(
        booking => booking.eventId === eventId && 
                  booking.status !== "canceled" && 
                  booking.status !== "refunded"
      );
      
      // Find which seats are booked for this table
      const bookedSeats = new Set<number>();
      eventBookings.forEach(booking => {
        if (booking.tableId === tableId) {
          booking.seatNumbers.forEach(seatNum => bookedSeats.add(seatNum));
        }
      });
      
      // For this implementation, assume each table has seats 1-4
      const tableSeats = Array.from({ length: 4 }, (_, i) => ({
        id: i + 1,
        tableId: tableId,
        seatNumber: i + 1,
        isAvailable: !bookedSeats.has(i + 1)
      }));

      res.json(tableSeats);
    } catch (error) {
      console.error("Error fetching seats:", error);
      res.status(500).json({ message: "Failed to fetch seats" });
    }
  });

  app.get("/api/food-options", async (_req, res) => {
    try {
      // Get food options ordered by display_order by default
      const options = await storage.getFoodOptionsByDisplayOrder();
      res.json(options);
    } catch (error) {
      console.error("Error fetching food options:", error);
      res.status(500).json({ message: "Failed to fetch food options" });
    }
  });
  
  app.get("/api/events/:eventId/food-options", async (req, res) => {
    try {
      const eventId = parseInt(req.params.eventId);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      // Get randomized food options for this event (3 per category)
      const options = await storage.getRandomizedFoodOptions(eventId);
      res.json(options);
    } catch (error) {
      console.error("Error fetching randomized food options:", error);
      res.status(500).json({ message: "Failed to fetch food options" });
    }
  });

  app.get("/api/bookings", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const bookings = await storage.getBookings();
      res.json(bookings);
    } catch (error) {
      console.error("Error fetching bookings:", error);
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });
  
  // API endpoints for admin logs
  app.get("/api/admin-logs", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      const logs = await storage.getAdminLogs();
      
      // Enrich logs with user data
      const enrichedLogs = await Promise.all(logs.map(async (log) => {
        const user = await storage.getUser(log.userId);
        return {
          ...log,
          user: user ? { id: user.id, email: user.email, role: user.role } : null
        };
      }));
      
      res.json(enrichedLogs);
    } catch (error) {
      console.error("Error fetching admin logs:", error);
      res.status(500).json({ message: "Failed to fetch admin logs" });
    }
  });
  
  // Check-in API endpoints
  app.post("/api/bookings/:id/check-in", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_manager", "staff", "hostess"].includes(req.user?.role)) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      // Check if an event ID was provided to validate booking
      const eventId = req.query.eventId ? parseInt(req.query.eventId as string) : null;
      
      console.log(`Processing check-in for booking ${bookingId} by staff ${req.user.id}${eventId ? ` for event ${eventId}` : ''}`);
      
      // Get booking first to determine if it's already checked in
      const existingBooking = await storage.getBookingById(bookingId);
      if (!existingBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Verify that the booking belongs to the specified event (if an event ID was provided)
      if (eventId !== null && existingBooking.eventId !== eventId) {
        return res.status(400).json({ 
          message: "Booking is for a different event",
          booking: existingBooking,
          eventId: existingBooking.eventId
        });
      }
      
      if (existingBooking.checkedIn) {
        return res.status(400).json({ 
          message: "Booking already checked in",
          booking: existingBooking
        });
      }
      
      // Process the check-in
      const updatedBooking = await storage.checkInBooking(bookingId, req.user.id);
      if (!updatedBooking) {
        return res.status(500).json({ message: "Failed to check in booking" });
      }
      
      // Broadcast check-in update to subscribed clients
      await broadcastCheckInUpdate(updatedBooking.eventId);
      
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error checking in booking:", error);
      res.status(500).json({ 
        message: "Failed to check in booking",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/bookings/:id/qr-scan", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_manager", "staff", "hostess"].includes(req.user?.role)) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      console.log(`QR scan lookup for booking ${bookingId}`);
      
      // Get detailed booking information 
      const booking = await storage.getBookingByQRCode(bookingId);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
    } catch (error) {
      console.error("Error performing QR scan lookup:", error);
      res.status(500).json({ 
        message: "Failed to verify QR code",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/events/:id/check-in-stats", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_manager", "staff", "hostess"].includes(req.user?.role)) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }
      
      console.log(`Getting check-in stats for event ${eventId}`);
      
      // Get statistics
      const stats = await storage.getEventCheckInStats(eventId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching check-in stats:", error);
      res.status(500).json({ 
        message: "Failed to fetch check-in statistics",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.get("/api/admin-logs/entity/:entityType", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const entityType = req.params.entityType;
      const logs = await storage.getAdminLogsByEntityType(entityType);
      
      // Enrich logs with user data
      const enrichedLogs = await Promise.all(logs.map(async (log) => {
        const user = await storage.getUser(log.userId);
        return {
          ...log,
          user: user ? { id: user.id, email: user.email, role: user.role } : null
        };
      }));
      
      res.json(enrichedLogs);
    } catch (error) {
      console.error(`Error fetching admin logs for entity type ${req.params.entityType}:`, error);
      res.status(500).json({ message: "Failed to fetch admin logs" });
    }
  });
  
  // Create a manual booking (admin only)
  app.post("/api/manual-booking", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      // Get the data from the request body
      console.log("Received manual booking request:", JSON.stringify(req.body, null, 2));
      
      // Ensure required fields are present
      const { eventId, userId, tableId, seatNumbers, customerEmail, foodSelections } = req.body;
      
      if (!eventId || !userId || !tableId || !seatNumbers || !seatNumbers.length || !customerEmail) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Prepare booking data with proper validation
      // Don't use schema validation as it might be too strict for manual bookings
      const bookingData = {
        eventId: Number(eventId),
        userId: Number(userId),
        tableId: Number(tableId),
        seatNumbers: seatNumbers,
        customerEmail: customerEmail,
        foodSelections: foodSelections || {},
        guestNames: req.body.guestNames || {},
        notes: req.body.notes || '',
        stripePaymentId: `manual-${Date.now()}-${req.user.id}`
      };
      
      console.log("Creating manual booking with data:", JSON.stringify(bookingData, null, 2));
      
      // Create the manual booking using admin's ID for tracking
      const booking = await storage.createManualBooking(bookingData, req.user.id);
      
      // Create detailed log entry for this action
      await storage.createAdminLog({
        userId: req.user.id,
        action: "create_manual_booking",
        entityType: "booking",
        entityId: booking?.id,
        details: { 
          bookingData: {
            id: booking?.id,
            eventId: Number(eventId),
            tableId: Number(tableId),
            seatNumbers: seatNumbers,
            customerEmail: customerEmail,
            userId: Number(userId)
          }
        }
      });
      
      console.log("Manual booking created successfully:", JSON.stringify(booking, null, 2));
      res.status(201).json(booking);
    } catch (error) {
      console.error("Error creating manual booking:", error);
      res.status(500).json({ 
        message: "Failed to create manual booking",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Reset all seats with no bookings to available
  app.post("/api/reset-seats", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized: Admin access required" });
      }

      // Get all events
      const allEvents = await db.select().from(events);
      // Get all bookings with confirmed status only
      const allBookings = await db.select().from(bookings).where(eq(bookings.status, "confirmed"));

      // For each event
      for (const event of allEvents) {
        // Get only confirmed bookings for this event
        const eventBookings = allBookings.filter(b => b.eventId === event.id);
        
        // Compute new available seats
        let newAvailableSeats = event.totalSeats;
        
        if (eventBookings.length === 0) {
          // If no bookings at all, reset available seats to total seats
          await db.update(events)
            .set({ availableSeats: newAvailableSeats })
            .where(eq(events.id, event.id));
        } else {
          // Count actual booked seats
          const bookedSeats = eventBookings.reduce((total, booking) => total + booking.seatNumbers.length, 0);
          newAvailableSeats = event.totalSeats - bookedSeats;
          await db.update(events)
            .set({ availableSeats: newAvailableSeats })
            .where(eq(events.id, event.id));
        }
        
        // Log the reset
        await storage.createAdminLog({
          userId: req.user.id,
          action: "reset_seats",
          entityType: "event",
          entityId: event.id,
          details: {
            eventTitle: event.title,
            totalSeats: event.totalSeats,
            previousAvailable: event.availableSeats,
            newAvailable: newAvailableSeats,
            confirmedBookings: eventBookings.length
          }
        });
      }

      res.status(200).json({ 
        success: true, 
        message: "All event seats have been reset based on confirmed bookings" 
      });
    } catch (error) {
      console.error("Error resetting seats:", error);
      res.status(500).json({ 
        success: false, 
        message: "Failed to reset seats",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Admin route to clear all bookings (for testing purposes)
  app.post("/api/clear-bookings", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized: Admin access required" });
      }
      
      const result = await clearAllBookings();
      
      if (result.success) {
        res.status(200).json(result);
      } else {
        res.status(500).json(result);
      }
    } catch (error) {
      console.error("Error clearing bookings:", error);
      res.status(500).json({ 
        success: false, 
        message: "Failed to clear bookings",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Route to update the order of events
  app.post("/api/events/order", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const validationResult = updateEventsOrderSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: "Invalid request body",
          errors: validationResult.error.format()
        });
      }
      
      const { orderedIds } = validationResult.data;
      await storage.updateEventsOrder(orderedIds);
      
      // Create detailed admin log for event ordering
      await storage.createAdminLog({
        userId: req.user.id,
        action: "update_events_order",
        entityType: "event",
        entityId: 0,  // Not tied to a specific event
        details: {
          orderedIds: orderedIds
        }
      });
      
      res.status(200).json({ success: true, message: "Events order updated successfully" });
    } catch (error) {
      console.error("Error updating events order:", error);
      res.status(500).json({
        success: false,
        message: "Failed to update events order",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Route to update the order of food options
  app.post("/api/food-options/order", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const validationResult = updateFoodOptionsOrderSchema.safeParse(req.body);
      if (!validationResult.success) {
        return res.status(400).json({
          message: "Invalid request body",
          errors: validationResult.error.format()
        });
      }
      
      const { orderedIds } = validationResult.data;
      await storage.updateFoodOptionsOrder(orderedIds);
      
      // Create detailed admin log for food options ordering
      await storage.createAdminLog({
        userId: req.user.id,
        action: "update_food_options_order",
        entityType: "food_option",
        entityId: 0,  // Not tied to a specific food option
        details: {
          orderedIds: orderedIds
        }
      });
      
      res.status(200).json({ success: true, message: "Food options order updated successfully" });
    } catch (error) {
      console.error("Error updating food options order:", error);
      res.status(500).json({
        success: false,
        message: "Failed to update food options order",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Serve uploaded images
  app.use('/uploads', express.static(uploadsDir));
  
  // Serve public images
  app.use('/images', express.static(path.join(process.cwd(), 'public/images')));
  
  // Serve files from the public directory
  app.use(express.static(path.join(process.cwd(), 'public')));
  
  // Custom error handler for multer upload errors
  const handleMulterError = (err: any, req: any, res: any, next: any) => {
    if (err instanceof multer.MulterError) {
      // A Multer error occurred when uploading
      console.error("Multer upload error:", err);
      return res.status(400).json({
        message: "Image upload failed",
        error: err.message,
        code: err.code
      });
    } else if (err) {
      // A file filter error or other non-multer error
      console.error("Upload error:", err);
      return res.status(400).json({
        message: "Image upload failed",
        error: err.message
      });
    }
    next();
  };
  
  // Handle food image uploads with improved error handling
  app.post("/api/upload/food-image", (req, res, next) => {
    // Explicitly wrap multer to catch and handle any errors
    console.log("Starting food image upload request");
    
    upload.single('image')(req, res, function(err) {
      if (err) {
        console.error("Multer upload error in food image:", err);
        return handleMulterError(err, req, res, next);
      }
      console.log("Multer processed food image request successfully");
      next();
    });
  }, async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        console.log("Unauthorized access to food image upload");
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      if (!req.file) {
        console.log("No food image file was received in the request");
        return res.status(400).json({ message: "No image file provided" });
      }
      
      console.log("Food image uploaded successfully:", {
        filename: req.file.filename,
        mimetype: req.file.mimetype,
        size: req.file.size,
        originalname: req.file.originalname
      });
      
      // Return the path to the uploaded file
      const filePath = `/uploads/${req.file.filename}`;
      
      // Create detailed admin log for food image upload
      await storage.createAdminLog({
        userId: req.user.id,
        action: "upload_food_image",
        entityType: "food_option",
        entityId: 0, // Not tied to a specific food option yet
        details: {
          filename: req.file.filename,
          originalname: req.file.originalname,
          filePath: filePath,
          size: req.file.size
        }
      });
      
      // Set appropriate content-type header to ensure JSON response
      res.setHeader('Content-Type', 'application/json');
      
      // Send response
      res.status(201).json({ 
        path: filePath,
        filename: req.file.filename,
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        success: true 
      });
    } catch (error) {
      console.error("Error uploading food image:", error);
      
      // Set appropriate content-type header to ensure JSON response
      res.setHeader('Content-Type', 'application/json');
      
      res.status(500).json({ 
        message: "Failed to upload image",
        error: error instanceof Error ? error.message : String(error),
        success: false
      });
    }
  });
  
  // Handle event image uploads with improved error handling
  app.post("/api/upload/event-image", (req, res, next) => {
    // Explicitly wrap multer to catch and handle any errors
    console.log("Starting event image upload request");
    
    upload.single('image')(req, res, function(err) {
      if (err) {
        console.error("Multer upload error in event image:", err);
        return handleMulterError(err, req, res, next);
      }
      console.log("Multer processed request successfully");
      next();
    });
  }, async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        console.log("Unauthorized access to event image upload");
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      if (!req.file) {
        console.log("No file was received in the request");
        return res.status(400).json({ message: "No image file provided" });
      }
      
      console.log("Event image uploaded successfully:", {
        filename: req.file.filename,
        mimetype: req.file.mimetype,
        size: req.file.size,
        originalname: req.file.originalname
      });
      
      // Return the path to the uploaded file
      const filePath = `/uploads/${req.file.filename}`;
      
      // Create detailed admin log for event image upload
      await storage.createAdminLog({
        userId: req.user.id,
        action: "upload_event_image",
        entityType: "event",
        entityId: 0, // Not tied to a specific event yet
        details: {
          filename: req.file.filename,
          originalname: req.file.originalname,
          filePath: filePath,
          size: req.file.size
        }
      });
      
      // Set appropriate content-type header to ensure JSON response
      res.setHeader('Content-Type', 'application/json');
      
      // Send response
      res.status(201).json({ 
        path: filePath,
        filename: req.file.filename,
        originalname: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        success: true 
      });
    } catch (error) {
      console.error("Error uploading event image:", error);
      
      // Set appropriate content-type header to ensure JSON response
      res.setHeader('Content-Type', 'application/json');
      
      res.status(500).json({ 
        message: "Failed to upload image",
        error: error instanceof Error ? error.message : String(error),
        success: false
      });
    }
  });

  app.get("/api/user/bookings", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const allBookings = await storage.getBookingDetails();
      const userBookings = allBookings.filter(booking => booking.userId === req.user?.id);
      res.json(userBookings);
    } catch (error) {
      console.error("Error fetching user bookings:", error);
      res.status(500).json({ message: "Failed to fetch user bookings" });
    }
  });

  // Add this route after the existing /api/users route
  app.get("/api/users", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Log user access to admin logs
      await storage.createAdminLog({
        userId: req.user.id,
        action: "view_users",
        entityType: "user",
        details: {
          adminEmail: req.user.email,
          timestamp: new Date().toISOString()
        }
      });

      // Get users and their bookings
      const users = await storage.getUsers();
      const allBookings = await storage.getBookingDetails();

      // Attach bookings to each user
      const usersWithBookings = users.map(user => ({
        ...user,
        bookings: allBookings.filter(booking => booking.userId === user.id)
      }));

      res.json(usersWithBookings);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  
  // Add endpoint to create new users (admin only)
  app.post("/api/users", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const { email, password, role } = req.body;
      
      if (!email || !password || !role) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(email);
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      
      // Hash the password
      const hashedPassword = await hashPassword(password);
      
      // Create the user
      const newUser = await storage.createUser({
        email,
        password: hashedPassword,
        role
      });
      
      // Log user creation
      await storage.createAdminLog({
        userId: req.user.id,
        action: "create_user",
        entityType: "user",
        entityId: newUser.id,
        details: {
          email: newUser.email,
          role: newUser.role,
          createdBy: req.user.email,
          timestamp: new Date().toISOString()
        }
      });
      
      // Hide password in response
      const { password: _, ...userResponse } = newUser;
      
      res.status(201).json(userResponse);
    } catch (error) {
      console.error("Error creating user:", error);
      res.status(500).json({ 
        message: "Failed to create user",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Add endpoint to update a user (admin only)
  app.patch("/api/users/:userId", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Get existing user
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const updates: Partial<Omit<InsertUser, "id">> = {};
      const changedFields: Record<string, { from: any, to: any }> = {};
      
      // Handle potential updates
      if (req.body.email && req.body.email !== existingUser.email) {
        // Check if new email already exists
        const userWithEmail = await storage.getUserByEmail(req.body.email);
        if (userWithEmail && userWithEmail.id !== userId) {
          return res.status(400).json({ message: "Email already in use" });
        }
        updates.email = req.body.email;
        changedFields.email = { 
          from: existingUser.email, 
          to: req.body.email 
        };
      }
      
      if (req.body.role && req.body.role !== existingUser.role) {
        updates.role = req.body.role;
        changedFields.role = { 
          from: existingUser.role, 
          to: req.body.role 
        };
      }
      
      if (req.body.password) {
        updates.password = await hashPassword(req.body.password);
        changedFields.password = { 
          from: "********", 
          to: "********" 
        };
      }
      
      // If no updates, return existing user
      if (Object.keys(updates).length === 0) {
        // Hide password in response
        const { password: userPassword, ...userResponse } = existingUser;
        return res.json(userResponse);
      }
      
      // Update the user
      const updatedUser = await storage.updateUser(userId, updates);
      
      // Log user update
      await storage.createAdminLog({
        userId: req.user.id,
        action: "update_user",
        entityType: "user",
        entityId: userId,
        details: {
          changedFields,
          updatedBy: req.user.email,
          timestamp: new Date().toISOString()
        }
      });
      
      // Hide password in response
      const { password: updatedPassword, ...userResponse } = updatedUser;
      
      res.json(userResponse);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ 
        message: "Failed to update user",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Add endpoint to delete a user (admin only)
  app.delete("/api/users/:userId", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      // Don't allow deleting self
      if (userId === req.user.id) {
        return res.status(400).json({ message: "Cannot delete your own account" });
      }
      
      // Get user to be deleted for logging
      const userToDelete = await storage.getUser(userId);
      if (!userToDelete) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Delete the user
      await storage.deleteUser(userId);
      
      // Log user deletion
      await storage.createAdminLog({
        userId: req.user.id,
        action: "delete_user",
        entityType: "user",
        entityId: userId,
        details: {
          deletedEmail: userToDelete.email,
          deletedRole: userToDelete.role,
          deletedBy: req.user.email,
          timestamp: new Date().toISOString()
        }
      });
      
      res.status(200).json({ message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ 
        message: "Failed to delete user",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.get("/api/user/:userId/bookings", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role !== "admin") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const userId = parseInt(req.params.userId);
      
      // Log admin viewing user bookings
      await storage.createAdminLog({
        userId: req.user.id,
        action: "view_user_bookings",
        entityType: "user",
        entityId: userId,
        details: {
          adminEmail: req.user.email,
          timestamp: new Date().toISOString()
        }
      });
      
      const allBookings = await storage.getBookingDetails();
      const userBookings = allBookings.filter(booking => booking.userId === userId);
      res.json(userBookings);
    } catch (error) {
      console.error("Error fetching user bookings:", error);
      res.status(500).json({ message: "Failed to fetch user bookings" });
    }
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      console.log("Creating booking with data:", JSON.stringify(req.body, null, 2));
      
      try {
        // Get the actual database fields to avoid trying to insert non-existent fields
        const bookingData = {
          eventId: req.body.eventId,
          userId: req.body.userId,
          tableId: req.body.tableId,
          seatNumbers: req.body.seatNumbers,
          foodSelections: req.body.foodSelections,
          guestNames: req.body.guestNames,
          customerEmail: req.body.customerEmail,
          stripePaymentId: req.body.stripePaymentId
        };
        
        var booking = insertBookingSchema.parse(bookingData);
      } catch (zodError) {
        if (zodError instanceof z.ZodError) {
          console.error("Validation error:", zodError.errors);
          return res.status(400).json({ 
            message: "Invalid booking data", 
            errors: zodError.errors
          });
        }
        throw zodError;
      }

      // Check if the event exists and has enough seats
      const event = await storage.getEvent(booking.eventId);
      if (!event) {
        console.log(`Event not found: ${booking.eventId}`);
        return res.status(404).json({ message: "Event not found" });
      }

      console.log(`Event available seats: ${event.availableSeats}, requested: ${booking.seatNumbers.length}`);
      if (event.availableSeats < booking.seatNumbers.length) {
        return res.status(400).json({ 
          message: "Not enough available seats for this booking" 
        });
      }
      
      // Verify the Stripe payment intent
      if (booking.stripePaymentId) {
        try {
          // Check if Stripe is properly initialized
          if (!stripe) {
            console.error("Stripe is not initialized. Cannot verify payment.");
            return res.status(500).json({ 
              error: "Payment verification service unavailable. Please contact support." 
            });
          }
          
          console.log(`Verifying Stripe payment intent: ${booking.stripePaymentId}`);
          const paymentIntent = await stripe.paymentIntents.retrieve(booking.stripePaymentId);
          
          if (paymentIntent.status !== 'succeeded') {
            console.error(`Payment verification failed. Status: ${paymentIntent.status}`);
            return res.status(400).json({ 
              message: `Payment not completed. Status: ${paymentIntent.status}` 
            });
          }
          
          console.log(`Payment verified: ${paymentIntent.id} with status ${paymentIntent.status}`);
        } catch (stripeError) {
          console.error("Stripe verification error:", stripeError);
          return res.status(400).json({ 
            message: "Could not verify payment", 
            error: stripeError instanceof Error ? stripeError.message : String(stripeError) 
          });
        }
      }
      
      console.log("Using temporary implementation for seat validation");
      // In our temporary implementation, we're not performing detailed seat validation
      // This will be reimplemented with the new approach

      console.log("Creating booking in database...");
      try {
        const created = await storage.createBooking(booking);
        console.log("Booking created:", JSON.stringify(created, null, 2));

        console.log("Updating event availability...");
        await storage.updateEventAvailability(
          booking.eventId,
          booking.seatNumbers.length
        );
        console.log("Event availability updated");
        
        // Log the customer booking
        await storage.createAdminLog({
          userId: req.user.id,
          action: "customer_booking_created",
          entityType: "booking",
          entityId: created.id,
          details: {
            eventId: booking.eventId,
            tableId: booking.tableId,
            seatCount: booking.seatNumbers.length,
            totalAmount: req.body.amount || 0,
            customerEmail: booking.customerEmail,
            date: new Date().toISOString()
          }
        });

        // Broadcast the update to all clients
        await broadcastAvailability(booking.eventId);

        res.status(201).json(created);
      } catch (dbError) {
        console.error("Database error during booking creation:", dbError);
        res.status(500).json({
          message: "Database error during booking creation",
          error: dbError instanceof Error ? dbError.message : String(dbError)
        });
      }
    } catch (error) {
      console.error("Unexpected error creating booking:", error);
      res.status(500).json({ 
        message: "Failed to create booking",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  // Add new endpoint for event food totals
  app.get("/api/events/:id/food-totals", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const eventId = parseInt(req.params.id);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }

      const totals = await storage.getEventFoodTotals(eventId);
      res.json(totals);
    } catch (error) {
      console.error("Error fetching event food totals:", error);
      res.status(500).json({ message: "Failed to fetch food totals" });
    }
  });
  
  // BOOKING MANAGEMENT ENDPOINTS
  
  // Get detailed booking info
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_owner", "venue_manager"].includes(req.user?.role || "")) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const booking = await storage.getBookingWithDetails(bookingId);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(booking);
    } catch (error) {
      console.error("Error fetching booking details:", error);
      res.status(500).json({ 
        message: "Failed to fetch booking details",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Update booking (generic updates)
  app.patch("/api/bookings/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_owner", "venue_manager"].includes(req.user?.role || "")) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const updates = req.body;
      const updatedBooking = await storage.updateBooking(bookingId, updates, req.user.id);
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error updating booking:", error);
      res.status(500).json({ 
        message: "Failed to update booking",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Change booking seats
  app.post("/api/bookings/:id/change-seats", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_owner", "venue_manager"].includes(req.user?.role || "")) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const { tableId, seatNumbers } = req.body;
      
      if (!tableId || !seatNumbers || !Array.isArray(seatNumbers) || seatNumbers.length === 0) {
        return res.status(400).json({ message: "Invalid request body. Required: tableId and seatNumbers array" });
      }
      
      // Get the original booking first for tracking changes
      const originalBooking = await storage.getBookingById(bookingId);
      if (!originalBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Store original seat information for logging
      const originalTableId = originalBooking.tableId;
      const originalSeatNumbers = originalBooking.seatNumbers;
      
      console.log("Using temporary implementation for seat validation in change-seats endpoint");
      // In our temporary implementation, we're not performing detailed seat validation
      // This will be reimplemented with the new approach
      
      const updatedBooking = await storage.changeBookingSeats(
        bookingId,
        tableId,
        seatNumbers,
        req.user.id
      );
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Create detailed admin log
      await storage.createAdminLog({
        userId: req.user.id,
        action: "change_booking_seats",
        entityType: "booking",
        entityId: bookingId,
        details: {
          from: {
            tableId: originalTableId,
            seatNumbers: originalSeatNumbers,
          },
          to: {
            tableId: tableId,
            seatNumbers: seatNumbers,
          },
          eventId: originalBooking.eventId,
          customerEmail: originalBooking.customerEmail
        }
      });
      
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error changing booking seats:", error);
      res.status(500).json({ 
        message: "Failed to change booking seats",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Update food selections
  app.post("/api/bookings/:id/change-food", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_owner", "venue_manager"].includes(req.user?.role || "")) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const { foodSelections } = req.body;
      
      if (!foodSelections || typeof foodSelections !== 'object') {
        return res.status(400).json({ message: "Invalid request body. Required: foodSelections object" });
      }
      
      // Get the original booking to track changes
      const originalBooking = await storage.getBookingById(bookingId);
      if (!originalBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Store original food selections for comparison
      const originalFoodSelections = originalBooking.foodSelections;
      
      const updatedBooking = await storage.updateBookingFoodSelections(
        bookingId,
        foodSelections,
        req.user.id
      );
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Create detailed admin log
      await storage.createAdminLog({
        userId: req.user.id,
        action: "update_booking_food",
        entityType: "booking",
        entityId: bookingId,
        details: {
          from: originalFoodSelections,
          to: foodSelections,
          eventId: originalBooking.eventId,
          customerEmail: originalBooking.customerEmail
        }
      });
      
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error updating food selections:", error);
      res.status(500).json({ 
        message: "Failed to update food selections",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Add a note to a booking
  app.post("/api/bookings/:id/add-note", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_owner", "venue_manager"].includes(req.user?.role || "")) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const { note } = req.body;
      
      if (!note || typeof note !== 'string' || note.trim() === '') {
        return res.status(400).json({ message: "Invalid request body. Required: non-empty note" });
      }
      
      // Get the booking before updating to capture changes for detailed logs
      const originalBooking = await storage.getBookingById(bookingId);
      if (!originalBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      const updatedBooking = await storage.addBookingNote(
        bookingId,
        note,
        req.user.id
      );
      
      // Create detailed admin log
      await storage.createAdminLog({
        userId: req.user.id,
        action: "add_booking_note",
        entityType: "booking",
        entityId: bookingId,
        details: {
          note: note,
          eventId: originalBooking.eventId,
          customerEmail: originalBooking.customerEmail
        }
      });
      
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error adding booking note:", error);
      res.status(500).json({ 
        message: "Failed to add booking note",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Process a refund
  app.post("/api/bookings/:id/refund", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_owner"].includes(req.user?.role || "")) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      const { amount } = req.body;
      
      if (typeof amount !== 'number' || amount <= 0) {
        return res.status(400).json({ message: "Invalid request body. Required: positive amount" });
      }
      
      // Get the booking to process refund
      const booking = await storage.getBookingById(bookingId);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Process the refund with Stripe
      try {
        // Check if Stripe is properly initialized
        if (!stripe) {
          console.error("Stripe is not initialized. Cannot process refund.");
          return res.status(500).json({ 
            error: "Refund service unavailable. Please contact support." 
          });
        }
        
        const refund = await stripe.refunds.create({
          payment_intent: booking.stripePaymentId,
          amount: Math.round(amount * 100), // Convert to cents
        });
        
        // Update booking record with refund info
        const updatedBooking = await storage.processRefund(
          bookingId,
          amount,
          refund.id,
          req.user.id
        );
        
        // Create detailed payment transaction log
        await storage.createAdminLog({
          userId: req.user.id,
          action: "process_refund",
          entityType: "payment",
          entityId: bookingId,
          details: {
            amount: amount,
            refundId: refund.id,
            paymentIntentId: booking.stripePaymentId,
            customerEmail: booking.customerEmail,
            eventId: booking.eventId,
            bookingId: bookingId,
            date: new Date().toISOString(),
            reason: req.body.reason || "Manual refund by admin",
            status: refund.status,
            processingDetails: {
              processor: "stripe",
              amountInCents: Math.round(amount * 100),
              currency: "usd",
              processorResponseCode: refund.status
            }
          }
        });
        
        // Create a booking-specific log as well
        await storage.createAdminLog({
          userId: req.user.id,
          action: "booking_refunded",
          entityType: "booking",
          entityId: bookingId,
          details: {
            amount: amount,
            refundId: refund.id,
            customerEmail: booking.customerEmail,
            eventId: booking.eventId,
            date: new Date().toISOString(),
            bookingStatus: "refunded"
          }
        });
        
        res.json(updatedBooking);
      } catch (stripeError: any) {
        console.error("Stripe refund error:", stripeError);
        return res.status(400).json({
          message: "Failed to process refund with Stripe",
          error: stripeError.message
        });
      }
    } catch (error) {
      console.error("Error processing refund:", error);
      res.status(500).json({ 
        message: "Failed to process refund",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Cancel a booking
  app.post("/api/bookings/:id/cancel", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !["admin", "venue_owner", "venue_manager"].includes(req.user?.role || "")) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const bookingId = parseInt(req.params.id);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }
      
      // Get the original booking first
      const originalBooking = await storage.getBookingById(bookingId);
      if (!originalBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      const updatedBooking = await storage.cancelBooking(bookingId, req.user.id);
      
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found" });
      }
      
      // Create detailed admin log
      await storage.createAdminLog({
        userId: req.user.id,
        action: "cancel_booking",
        entityType: "booking",
        entityId: bookingId,
        details: {
          reason: req.body.reason || "Administrative cancellation",
          customerEmail: originalBooking.customerEmail,
          eventId: originalBooking.eventId,
          tableId: originalBooking.tableId,
          seatNumbers: originalBooking.seatNumbers,
          date: new Date().toISOString()
        }
      });
      
      res.json(updatedBooking);
    } catch (error) {
      console.error("Error canceling booking:", error);
      res.status(500).json({ 
        message: "Failed to cancel booking",
        error: error instanceof Error ? error.message : String(error) 
      });
    }
  });

  // Add these routes after the existing event routes
  app.post("/api/food-options", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      console.log("Creating food option with data:", req.body);
      const foodOption = await storage.createFoodOption(req.body);
      console.log("Food option created successfully:", foodOption);
      
      // Create detailed admin log for food option creation
      await storage.createAdminLog({
        userId: req.user.id,
        action: "create_food_option",
        entityType: "food_option",
        entityId: foodOption.id,
        details: {
          name: foodOption.name,
          type: foodOption.type,
          allergens: foodOption.allergens,
          dietaryRestrictions: foodOption.dietaryRestrictions,
          price: foodOption.price
        }
      });
      
      res.status(201).json(foodOption);
    } catch (error) {
      console.error("Error creating food option:", error);
      res.status(500).json({ 
        message: "Failed to create food option",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });

  app.patch("/api/food-options/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      
      // Get original food option before updates for better logging
      const originalFoodOption = await storage.getFoodOptionsByIds([id]);
      if (!originalFoodOption || originalFoodOption.length === 0) {
        return res.status(404).json({ message: "Food option not found" });
      }
      
      const foodOption = await storage.updateFoodOption(id, req.body);
      if (!foodOption) {
        return res.status(404).json({ message: "Food option not found after update" });
      }
      
      // Track specific changes for more detailed logging
      const changes: Record<string, { from: any, to: any }> = {};
      for (const key of Object.keys(req.body)) {
        if (JSON.stringify(originalFoodOption[0][key as keyof typeof originalFoodOption[0]]) !== 
            JSON.stringify(foodOption[key as keyof typeof foodOption])) {
          changes[key] = {
            from: originalFoodOption[0][key as keyof typeof originalFoodOption[0]],
            to: foodOption[key as keyof typeof foodOption]
          };
        }
      }
      
      // Create detailed admin log for food option update with specific changes
      await storage.createAdminLog({
        userId: req.user.id,
        action: "update_food_option",
        entityType: "food_option",
        entityId: id,
        details: {
          name: foodOption.name,
          type: foodOption.type,
          changes: changes,
          price: foodOption.price
        }
      });
      
      res.json(foodOption);
    } catch (error) {
      console.error("Error updating food option:", error);
      res.status(500).json({ message: "Failed to update food option" });
    }
  });

  app.delete("/api/food-options/:id", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const id = parseInt(req.params.id);
      
      // Get food option before deletion for logging
      const foodOption = await storage.getFoodOptionsByIds([id]);
      if (!foodOption || foodOption.length === 0) {
        return res.status(404).json({ message: "Food option not found" });
      }
      
      await storage.deleteFoodOption(id);
      
      // Create detailed admin log for food option deletion
      await storage.createAdminLog({
        userId: req.user.id,
        action: "delete_food_option",
        entityType: "food_option",
        entityId: id,
        details: {
          name: foodOption[0].name,
          type: foodOption[0].type
        }
      });
      
      res.sendStatus(200);
    } catch (error) {
      console.error("Error deleting food option:", error);
      res.status(500).json({ message: "Failed to delete food option" });
    }
  });

  // Generate a payment token for secure payment processing
  app.post("/api/generate-payment-token", async (req, res) => {
    // Capture detailed connection information for debugging
    const authInfo = {
      hasSession: !!req.session,
      hasSessionID: !!req.sessionID,
      cookiesHeader: req.headers.cookie ? 'Present' : 'Missing',
      isAuthenticated: req.isAuthenticated ? req.isAuthenticated() : false,
      origin: req.headers.origin || 'unknown',
      userAgent: req.headers['user-agent'] || 'unknown',
      requestPath: req.path,
      method: req.method,
      noCredentialsMode: !!req.body.noCredentials,
      hasUserIdInBody: !!req.body.userId
    };
    
    console.log(`Payment token request received with auth info:`, authInfo);
    
    // Primary authentication flow: standard session authentication
    if (req.isAuthenticated && req.isAuthenticated() && req.user) {
      // Generate a temporary payment token tied to this user
      const paymentToken = require('crypto').randomBytes(32).toString('hex');
      
      // Store the token with an expiry time and user info
      const tokenData = {
        userId: req.user.id,
        userEmail: req.user.email,
        expires: Date.now() + (90 * 60 * 1000), // 90 minutes (extended for reliability)
        created: Date.now(),
        sessionId: req.sessionID || 'unknown'
      };
      
      // Use app locals to store tokens (in production you'd use Redis or similar)
      if (!app.locals.paymentTokens) {
        app.locals.paymentTokens = {};
      }
      app.locals.paymentTokens[paymentToken] = tokenData;
      
      console.log(`Generated payment token for user ${req.user.id} (${req.user.email})`);
      
      // Return the token to the client
      return res.json({ paymentToken });
    } 
    // Secondary authentication flow: email + userId match (for requests without credentials)
    // This is used as a fallback when session cookies can't be sent due to CORS issues
    else if (req.body.email && req.body.userId && req.body.noCredentials) {
      try {
        console.log(`Attempting non-credentialed token generation with email ${req.body.email} and user ID ${req.body.userId}`);
        
        // Verify the user exists and matches both email and ID
        const user = await storage.getUser(Number(req.body.userId));
        
        if (user && user.email === req.body.email) {
          console.log(`Verified user match for direct auth: ${user.id} (${user.email})`);
          
          // Generate a temporary payment token with limited privileges
          const paymentToken = require('crypto').randomBytes(32).toString('hex');
          
          // Store the token with limited rights
          const tokenData = {
            userId: user.id,
            userEmail: user.email,
            expires: Date.now() + (45 * 60 * 1000), // 45 minutes
            created: Date.now(),
            directAuth: true,  // Mark as directly authenticated
            limitedAccess: true // Mark as limited access
          };
          
          // Store the token
          if (!app.locals.paymentTokens) {
            app.locals.paymentTokens = {};
          }
          app.locals.paymentTokens[paymentToken] = tokenData;
          
          console.log(`Generated direct auth token for user ${user.id}`);
          
          // Return the token to the client
          return res.json({ 
            paymentToken, 
            limitedAccess: true,
            directAuth: true
          });
        } else {
          console.log(`User verification failed for direct auth request`);
        }
      } catch (error) {
        console.error(`Error in direct auth token generation:`, error);
      }
    }
    // Tertiary authentication flow: email-only lookup
    else if (req.body.email) {
      try {
        // Attempt to look up user by email - only for very specific payment flows
        const user = await storage.getUserByEmail(req.body.email);
        
        if (user) {
          console.log(`Found user by email backup method: ${user.id} (${user.email})`);
          
          // Generate a temporary payment token with limited privileges
          const paymentToken = require('crypto').randomBytes(32).toString('hex');
          
          // Store the token with shorter expiry and limited access flag
          const tokenData = {
            userId: user.id,
            userEmail: user.email,
            expires: Date.now() + (30 * 60 * 1000), // 30 minutes
            created: Date.now(),
            limitedAccess: true // Mark as limited access token
          };
          
          // Store the token
          if (!app.locals.paymentTokens) {
            app.locals.paymentTokens = {};
          }
          app.locals.paymentTokens[paymentToken] = tokenData;
          
          console.log(`Generated limited payment token for user ${user.id} via email fallback`);
          
          // Return the token to the client
          return res.json({ paymentToken, limitedAccess: true });
        }
      } catch (error) {
        console.error(`Error in email-based token generation:`, error);
      }
    }
    
    // If we get here, authentication failed through all methods
    console.log("Payment token request rejected: Not authenticated through any method");
    return res.status(401).json({ 
      message: "Unauthorized",
      error: "You must be logged in to get a payment token",
      authInfo // Include auth info for debugging
    });
  });

  // Stripe payment integration
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      // Capture detailed connection information for debugging
      const authInfo = {
        hasSession: !!req.session,
        hasSessionID: !!req.sessionID,
        cookiesHeader: req.headers.cookie ? 'Present' : 'Missing',
        isAuthenticated: req.isAuthenticated ? req.isAuthenticated() : false,
        origin: req.headers.origin || 'unknown',
        userAgent: req.headers['user-agent'] || 'unknown',
        requestPath: req.path,
        method: req.method,
        hasPaymentToken: !!req.body.paymentToken,
        hasEmail: !!req.body.userEmail,
        hasUserId: !!req.body.userId
      };
      
      console.log(`Payment intent request received with auth info:`, authInfo);

      // First check for session-based authentication
      const isAuthenticatedViaSession = req.isAuthenticated() && !!req.user;
      
      // Then check for token-based authentication as fallback
      let isAuthenticatedViaToken = false;
      let tokenUser = null;
      
      const { paymentToken } = req.body;
      if (paymentToken && app.locals.paymentTokens && app.locals.paymentTokens[paymentToken]) {
        const tokenData = app.locals.paymentTokens[paymentToken];
        
        // Verify token is still valid
        if (tokenData.expires > Date.now()) {
          isAuthenticatedViaToken = true;
          tokenUser = {
            id: tokenData.userId,
            email: tokenData.userEmail
          };
          console.log(`Authentication via payment token for user ${tokenUser.id}`);
        } else {
          // Token expired
          delete app.locals.paymentTokens[paymentToken];
          console.log(`Expired payment token used`);
        }
      }
      
      // Final fallback: direct authentication using email and userId
      let isAuthenticatedDirectly = false;
      let directUser = null;
      
      if (!isAuthenticatedViaSession && !isAuthenticatedViaToken && req.body.userEmail && req.body.userId) {
        try {
          console.log(`Attempting direct authentication for user ID: ${req.body.userId}, email: ${req.body.userEmail}`);
          
          // Verify that both the ID and email match a user in our database
          const user = await storage.getUser(Number(req.body.userId));
          
          if (user && user.email === req.body.userEmail) {
            isAuthenticatedDirectly = true;
            directUser = {
              id: user.id,
              email: user.email
            };
            console.log(`Direct authentication successful for user ${user.id} (${user.email})`);
          } else {
            console.log(`Direct authentication failed - user mismatch or not found`);
          }
        } catch (directAuthError) {
          console.error(`Error in direct authentication:`, directAuthError);
        }
      }
      
      // Enhanced authentication checking with detailed logging
      if (!isAuthenticatedViaSession && !isAuthenticatedViaToken && !isAuthenticatedDirectly) {
        console.log("Payment intent request rejected: Authentication status:", {
          isAuthenticatedViaSession,
          isAuthenticatedViaToken,
          isAuthenticatedDirectly,
          cookies: req.headers.cookie ? 'Present' : 'Missing',
          path: req.path,
          ...authInfo // Spread authInfo which already has hasSessionID and hasPaymentToken
        });
        return res.status(401).json({ 
          message: "Unauthorized", 
          error: "You must be logged in to process payments", 
          code: "AUTH_REQUIRED",
          authInfo // Include auth info for debugging
        });
      }
      
      // Use the authenticated user from whichever method succeeded
      // We select from the three possible authentication methods
      const user = isAuthenticatedViaSession ? req.user : 
                   isAuthenticatedViaToken ? tokenUser : 
                   directUser;
      
      // Safety check - this should never happen due to earlier guards, but we keep it for runtime safety
      if (!user) {
        console.error("Critical error: User is null after authentication check");
        return res.status(500).json({ 
          error: "Authentication error", 
          code: "AUTH_ERROR"
        });
      }
      
      // Log user information for debugging
      console.log(`Payment request authenticated for user: ${user.id} (${user.email})${isAuthenticatedViaSession ? `, session ID: ${req.sessionID.substring(0, 8)}...` : ' via token'}`);
      
      console.log(`Payment intent requested by user ${user.id} (${user.email})`);
      
      // Verify environment variables are set
      if (!process.env.STRIPE_SECRET_KEY) {
        console.error("Missing STRIPE_SECRET_KEY environment variable");
        return res.status(500).json({ 
          error: "Payment service configuration error. Please contact support.",
          code: "MISSING_STRIPE_KEY" 
        });
      }
      
      // Check if Stripe is properly initialized
      if (!stripe) {
        console.error("Stripe is not initialized. Attempting to initialize now...");
        
        // Try to initialize Stripe with our retry function
        if (!initializeStripe() && stripeInitAttempt < MAX_INIT_ATTEMPTS) {
          // Try one more time after a short delay
          await new Promise(resolve => setTimeout(resolve, 1000));
          if (!initializeStripe()) {
            console.error(`Failed to initialize Stripe after ${stripeInitAttempt} attempts`);
            return res.status(503).json({ 
              error: "Payment service temporarily unavailable. Please try again later.",
              code: "STRIPE_INIT_FAILED"
            });
          }
        }
      }
      
      // Validate the request payload
      if (!req.body || typeof req.body.seatCount !== 'number' || req.body.seatCount < 1) {
        return res.status(400).json({
          error: "Invalid request. Seat count must be a positive number.",
          code: "INVALID_SEAT_COUNT"
        });
      }
      
      // For testing, we'll use a fixed amount (like $19.99 for each seat)
      // In production, you would calculate this based on event prices, food choices, etc.
      const { seatCount } = req.body;
      const unitPrice = 1999; // $19.99 in cents (Stripe uses cents as the base unit)
      const amount = unitPrice * seatCount;
      
      // Add metadata for tracking
      const metadata = {
        userId: user.id.toString(),
        seats: seatCount.toString(),
        timestamp: new Date().toISOString()
      };
      
      console.log(`Creating payment intent for amount: ${amount} cents, user: ${user.id}, seats: ${seatCount}`);
      
      // Create the payment intent with Stripe with better error handling
      let paymentIntent;
      try {
        // Double-check Stripe is initialized (type safety)
        if (!stripe) {
          throw new Error("Stripe is not properly initialized");
        }
        
        paymentIntent = await stripe.paymentIntents.create({
          amount,
          currency: "usd",
          metadata,
          // Use automatic payment methods for simplicity in testing
          automatic_payment_methods: {
            enabled: true,
          },
        });
      } catch (stripeError: any) {
        console.error("Stripe API error when creating payment intent:", stripeError);
        
        let errorMessage = "Payment processing failed";
        let errorCode = "STRIPE_API_ERROR";
        
        // Map specific Stripe error types to user-friendly messages
        if (stripeError.type === 'StripeCardError') {
          errorMessage = "Your card was declined. Please try another payment method.";
          errorCode = "CARD_DECLINED";
        } else if (stripeError.type === 'StripeInvalidRequestError') {
          errorMessage = "Invalid payment request. Please check your information.";
          errorCode = "INVALID_REQUEST";
        } else if (stripeError.type === 'StripeAPIError') {
          errorMessage = "Payment service is experiencing technical difficulties. Please try again later.";
          errorCode = "API_ERROR";
        } else if (stripeError.type === 'StripeConnectionError') {
          errorMessage = "Could not connect to payment service. Please check your internet connection and try again.";
          errorCode = "CONNECTION_ERROR";
        }
        
        return res.status(422).json({
          error: errorMessage,
          code: errorCode,
          detail: stripeError.message
        });
      }
      
      if (!paymentIntent || !paymentIntent.client_secret) {
        console.error("Payment intent created but missing client secret");
        return res.status(500).json({
          error: "Payment setup incomplete. Please try again.",
          code: "MISSING_CLIENT_SECRET"
        });
      }
      
      // Create payment transaction log
      try {
        await storage.createAdminLog({
          userId: user.id,
          action: "create_payment_intent",
          entityType: "payment",
          entityId: 0, // No specific entity ID for the payment intent yet
          details: {
            paymentIntentId: paymentIntent.id,
            amount: amount / 100, // Convert cents to dollars for readability
            currency: "usd",
            customerEmail: user.email,
            metadata: metadata,
            createdAt: new Date().toISOString(),
            status: paymentIntent.status,
            authMethod: isAuthenticatedViaSession ? 'session' : 'token'
          }
        });
      } catch (logError) {
        // Don't fail the request if just the logging fails
        console.error("Error logging payment intent creation:", logError);
      }
      
      // Return only the client secret to the client to complete the payment
      res.status(200).json({ 
        clientSecret: paymentIntent.client_secret,
        amount
      });
    } catch (error) {
      console.error("Unexpected error creating payment intent:", error);
      res.status(500).json({ 
        error: error instanceof Error 
          ? error.message 
          : "An unexpected error occurred. Please try again later.",
        code: "UNKNOWN_ERROR"
      });
    }
  });

  // Enhanced Stripe diagnostic endpoint - provides detailed connectivity information
  app.get("/api/stripe-diagnostics", async (req, res) => {
    try {
      // Collect diagnostic information
      const diagnostics: any = {
        environment: {
          nodeEnv: process.env.NODE_ENV || 'not set',
          hasStripeSecretKey: !!process.env.STRIPE_SECRET_KEY,
          stripeSecretKeyPrefix: process.env.STRIPE_SECRET_KEY 
            ? process.env.STRIPE_SECRET_KEY.substring(0, 7) + '...' 
            : 'missing',
          stripeApiVersionConfigured: stripeApiVersion,
          deployedUrl: req.protocol + '://' + req.get('host'),
        },
        stripeInstance: {
          initialized: !!stripe,
          apiVersion: (stripe as any)?.apiVersion || stripeApiVersion,
        },
        tests: {
          connectivity: {
            success: false,
            startTime: new Date().toISOString(),
            endTime: null as any,
            durationMs: 0,
            error: null as any
          },
          authentication: {
            success: false,
            startTime: new Date().toISOString(),
            endTime: null as any,
            durationMs: 0,
            error: null as any
          }
        }
      };

      // If Stripe is not initialized, try to initialize it
      if (!stripe && process.env.STRIPE_SECRET_KEY) {
        try {
          console.log("Attempting to initialize Stripe during diagnostics");
          stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
            apiVersion: stripeApiVersion
          });
          diagnostics.stripeInstance.initialized = true;
          diagnostics.stripeInstance.apiVersion = (stripe as any).apiVersion || stripeApiVersion;
        } catch (initError: any) {
          diagnostics.tests.connectivity.error = {
            message: "Failed to initialize Stripe instance",
            details: initError instanceof Error ? initError.message : String(initError),
            code: initError.code || 'INIT_ERROR'
          };
        }
      }
      
      // Only run tests if Stripe is properly initialized
      if (stripe) {
        // Test 1: Basic connectivity
        try {
          const startTime = Date.now();
          // Ping Stripe API without authentication to test network connectivity
          const response = await fetch('https://api.stripe.com/v1/ping', { method: 'GET' });
          const endTime = Date.now();
          
          diagnostics.tests.connectivity = {
            success: response.status < 500, // Even 401 is ok for connectivity test
            startTime: new Date(startTime).toISOString(),
            endTime: new Date(endTime).toISOString(),
            durationMs: endTime - startTime,
            statusCode: response.status,
            statusText: response.statusText,
            error: null
          };
        } catch (connError: any) {
          diagnostics.tests.connectivity.endTime = new Date().toISOString();
          diagnostics.tests.connectivity.error = {
            message: "Network connectivity to Stripe failed",
            details: connError instanceof Error ? connError.message : String(connError),
            code: 'NETWORK_ERROR'
          };
        }
        
        // Test 2: Authentication
        try {
          const startTime = Date.now();
          // Double-check stripe is still available (for type safety)
          if (!stripe) {
            throw new Error("Stripe instance lost during diagnostics");
          }
          // Try to fetch something simple from Stripe to verify authentication
          const customers = await stripe.customers.list({ limit: 1 });
          const endTime = Date.now();
          
          diagnostics.tests.authentication = {
            success: true,
            startTime: new Date(startTime).toISOString(),
            endTime: new Date(endTime).toISOString(),
            durationMs: endTime - startTime,
            hasResults: customers.data.length > 0,
            error: null
          };
        } catch (authError: any) {
          const endTime = Date.now();
          diagnostics.tests.authentication = {
            success: false,
            startTime: diagnostics.tests.authentication.startTime,
            endTime: new Date(endTime).toISOString(),
            durationMs: endTime - Date.parse(diagnostics.tests.authentication.startTime),
            error: {
              message: "Stripe authentication failed",
              details: authError instanceof Error ? authError.message : String(authError),
              type: authError.type || 'UNKNOWN',
              code: authError.code || 'AUTH_ERROR',
              statusCode: authError.statusCode
            }
          };
        }
      }
      
      // Send the full diagnostic report
      res.json({
        timestamp: new Date().toISOString(),
        overall: {
          initialized: diagnostics.stripeInstance.initialized,
          connected: diagnostics.tests.connectivity.success,
          authenticated: diagnostics.tests.authentication.success,
          ready: diagnostics.stripeInstance.initialized && 
                 diagnostics.tests.connectivity.success && 
                 diagnostics.tests.authentication.success
        },
        diagnostics
      });
      
    } catch (error) {
      console.error("Stripe diagnostics failed:", error);
      res.status(500).json({ 
        success: false,
        message: "Failed to run Stripe diagnostics", 
        error: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString()
      });
    }
  });
  
  // Original simple test endpoint (keeping for backward compatibility)
  app.get("/api/stripe-test", async (req, res) => {
    try {
      // Check if Stripe is properly initialized
      if (!stripe) {
        console.error("Stripe is not initialized. Cannot run test.");
        return res.status(500).json({ 
          success: false,
          message: "Stripe is not initialized", 
          error: "Payment service unavailable. Please check environment variables."
        });
      }
      
      // Try to fetch something simple from Stripe to verify the connection
      await stripe.customers.list({ limit: 1 });
      
      res.json({ 
        success: true, 
        message: "Stripe connection successful"
      });
    } catch (error) {
      console.error("Stripe test failed:", error);
      res.status(500).json({ 
        success: false,
        message: "Stripe connection failed", 
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Admin logs are already handled by the endpoint at line ~370
  // Manual booking endpoint is already defined at line ~419

  // Ticket check-in endpoints
  app.get("/api/bookings/:bookingId/scan", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const bookingId = parseInt(req.params.bookingId);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }

      const booking = await storage.getBookingByQRCode(bookingId);
      if (!booking) {
        return res.status(404).json({ message: "Booking not found" });
      }

      res.json(booking);
    } catch (error) {
      console.error("Error scanning booking:", error);
      res.status(500).json({ message: "Failed to scan booking" });
    }
  });

  app.post("/api/bookings/:bookingId/check-in", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const bookingId = parseInt(req.params.bookingId);
      if (isNaN(bookingId)) {
        return res.status(400).json({ message: "Invalid booking ID" });
      }

      const updatedBooking = await storage.checkInBooking(bookingId, req.user.id);
      if (!updatedBooking) {
        return res.status(404).json({ message: "Booking not found or already checked in" });
      }

      // Broadcast check-in update to all connected clients
      const message = JSON.stringify({
        type: 'check_in_update',
        bookingId: updatedBooking.id,
        eventId: updatedBooking.eventId,
        checkedIn: updatedBooking.checkedIn,
        checkedInAt: updatedBooking.checkedInAt
      });

      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(message);
        }
      });

      res.json(updatedBooking);
    } catch (error) {
      console.error("Error checking in booking:", error);
      res.status(500).json({ message: "Failed to check in booking" });
    }
  });

  app.get("/api/events/:eventId/check-in-stats", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const eventId = parseInt(req.params.eventId);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }

      const stats = await storage.getEventCheckInStats(eventId);
      res.json(stats);
    } catch (error) {
      console.error("Error getting check-in stats:", error);
      res.status(500).json({ message: "Failed to get check-in stats" });
    }
  });

  app.get("/api/events/:eventId/checked-in-bookings", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user?.role === "customer") {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const eventId = parseInt(req.params.eventId);
      if (isNaN(eventId)) {
        return res.status(400).json({ message: "Invalid event ID" });
      }

      const checkedInBookings = await storage.getCheckedInBookings(eventId);
      res.json(checkedInBookings);
    } catch (error) {
      console.error("Error getting checked-in bookings:", error);
      res.status(500).json({ message: "Failed to get checked-in bookings" });
    }
  });

  return httpServer;
}